<form method="POST" enctype="multipart/form-data" action="send-mail.php">
	<p>
		Send to:
		<input type="text" name="receiver">
	</p>

	<p>
		Subject:
		<input type="text" name="subject">
	</p>

	<p>
		Message:
		<textarea name="message"></textarea>
	</p>

	<p>
		Select file:
		<input type="file" name="file">
	</p>

	<input type="submit">
</form>